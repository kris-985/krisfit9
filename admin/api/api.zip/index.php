<?php

require 'classes/Autoloader.php';
Autoloader::register();

require "config.php";
require "functions.php";

require "router/index.php";